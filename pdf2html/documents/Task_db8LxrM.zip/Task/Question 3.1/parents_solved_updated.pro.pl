% parents.pro
% GHL
%   you may add your own facts and rules, but leave the current facts and rules in this file also

% Facts

female(frances).               % my mother
female(barbara).               % karen's mother
female(karen).                 % my wife
female(kathy).                 % karen's sister
female(carrie).                %   "
female(laurie).                %   "
female(connie).                %   "
female(sabrina).               % my daughter
female(valerie).               %   "
female(joya).                  %   "
female(kallie).                %   "
female(tessa).                 % my granddaughter
female(meriel).                %   "
male(oliver).                  % my father
male(robert).                  % karen's father
male(gary).                    % me
male(rob).                     % karen's brother
male(josh).                    % my son
male(david).                   %   "
male(daniel).                  %   "
male(geoff).                   %   "
male(matthew).		       %   "
male(sam).                     % my grandson
male(jahleel).                 %   "
male(camden).                  %   "
male(michael).                 %   "
male(peyton).                  %   "
male(ollie).                   %   "
male(leif).                    %   "


parents(josh,gary,karen).      % format (Offspring, Father, Mother)
parents(sabrina,gary,karen).
parents(david,gary,karen).
parents(daniel,gary,karen).
parents(valerie,gary,karen).
parents(gary,oliver,frances).
parents(karen,robert,barbara).
parents(rob,robert,barbara).
parents(laurie,robert,barbara).
parents(connie,robert,barbara).
parents(kathy,robert,barbara).
parents(carrie,robert,barbara).
parents(tessa, josh, joya).
parents(sam, josh, joya).
parents(michael, josh, joya).
parents(ollie, josh, joya).
parents(meriel, geoff, sabrina).
parents(leif, geoff, sabrina).
parents(jahleel, david, kallie).
parents(camden, david, kallie).
parents(peyton, david, kallie).

% My Define Rules
parent(josh, gary).
parent(josh, karen).
parent(david, gary).
parent(sabrina, gary).
parent(sabrina, karen).
parent(david, gary).
parent(david, karen).
parent(gary, oliver).
parent(gary, frances).

married(oliver, frances).
married(gary, karen).


% Rules

% 1 
% you need to modify so someone is not her own sister
sister_of(Sister, Sibling) :-
  female(Sister),
  parents(Sister, Father, Mother),
  parents(Sibling, Father, Mother).

% 2
% your mother of father's sister
father(Child, Dad) :- male(Dad), parent(Child, Dad).
mother(Child, Mom) :- female(Mom), parent(Child, Mom).
aunt(Aunt, Nephewneice) :- female(Aunt), parent(Nephewneice, Parent), sister_of(Parent, Aunt).

%3 
% your mother's or father's father
grandpa_of(Granddad, Grandperson) :- 
    male(Granddad), 
    parent(Grandperson, Parent), 
    parent(Parent, Granddad).

% 4
% make up something interesting related to families; it should not be similar to any of thse rules
mother_in_law(child_in_law, min_law) :- female(min_law), married(child_in_law, Child), parent(Child, min_law).
    


