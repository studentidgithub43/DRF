# Loading the IRIS Dataset from sci-kit learn library
from sklearn import neighbors
from sklearn import  datasets
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split


iris = datasets.load_iris()

# Assign the data and target to separate variables.
x = iris.data
y = iris.target

x[0], y[0]

# Since our process involve training and testing ,We should split our dataset.It can be executed by the following code
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=.5)

# Note:We can also use KNeighborsClassifier(efficiency is higher)
classifier = neighbors.KNeighborsClassifier()

# We can train the model with fit function.
classifier.fit(x_train, y_train)

# Predictions can be done with predict function
predictions = classifier.predict(x_test)

# these predictions can be matched with the expected output to measure the accuracy value.
print(accuracy_score(y_test, predictions))

# [5.8, 2.7, 4.1, 1. ]
# x_test, y_test
pred_c = classifier.predict(x_test[0].reshape(1, -1))

# i have selected the random x_test value let say [5.8, 2.7, 4.1, 1. ] their target value is 1 in the data. i have predict this x_test value using this system the system predicts correctly of the value of 1.